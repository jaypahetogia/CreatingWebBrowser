package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;

public class BrowserTab extends Tab {
	
	private final WebEngine webEngine;
	
	
	public BrowserTab() {
	
		WebView webView = new WebView();
		webEngine = webView.getEngine();
		setContent(createBrowserContent());	
		setOnClosed(e->webView.getEngine().load(null)); //stop loading to free resources
		
		webEngine.titleProperty().addListener((observable, oldValue, newValue)-> {
			setText(newValue); //setting the title of the tab as the web page title
		});
	}
	
	
	private VBox createBrowserContent() {
		WebView webView1 = new WebView();
		webView1.getEngine().load("http://www.google.com");
		WebEngine webEngine1 = webView1.getEngine();
		
		TextField textField = new TextField();
		Runnable loadURL = ()-> {
			String url = textField.getText();
			if(!url.contains(" ") && (url.startsWith("http://") || url.startsWith("https://") || url.contains("."))) {
				if(!url.startsWith("http://") && !url.startsWith("https://")) {
					url = "http://"+url;
				}
				webEngine1.load(url);
			}
			else {
				String googleSearch = "https://www.google.com/search?q=" + url.replace(" ", "+");
				webEngine1.load(googleSearch);
			}
		};
		
		Button homeButton = new Button();
		ImageView homeImage = new ImageView("/images/homegreen.png");
		homeImage.setFitWidth(18);
		homeImage.setFitHeight(18);
		homeButton.setGraphic(homeImage);
		homeButton.setOnAction(e->webEngine1.load("http://www.google.com"));
		
		MenuButton settingsButton = new MenuButton();
		ImageView settingsImage = new ImageView("/images/settingsgreen.png");
		settingsImage.setFitWidth(18);
		settingsImage.setFitHeight(18);
		settingsButton.setGraphic(settingsImage);
		settingsButton.getItems().addAll(new MenuItem("Color themes"), new MenuItem("Zoom"), new MenuItem("App Store"), new MenuItem("Privacy"), new MenuItem("Properties"), new MenuItem("Advanced"));
		
		
		Button refreshButton = new Button();
		ImageView refreshImage = new ImageView("/images/refreshgreen.png");
		refreshImage.setFitWidth(18);
		refreshImage.setFitHeight(18);
		refreshButton.setGraphic(refreshImage);
		refreshButton.setOnAction(e->webEngine1.reload());
		
		
		
Button backButton = new Button();
ImageView backImage = new ImageView("/images/backgreen.png");
backImage.setFitWidth(18);
backImage.setFitHeight(18);
backButton.setGraphic(backImage);
backButton.setOnAction(e-> {
	final WebHistory history = webEngine1.getHistory();
	int currentIndex = history.getCurrentIndex();
	
	//check if there's a previous page
	if(currentIndex>0) {
		history.go(-1);
	}
});

	
	Button forwardButton = new Button();
	ImageView forwardImage = new ImageView("/images/forwardgreen.png");
	forwardImage.setFitWidth(18);
	forwardImage.setFitHeight(18);
	forwardButton.setGraphic(forwardImage);
	forwardButton.setOnAction(e-> {
		final WebHistory history = webEngine1.getHistory();
		int currentIndex = history.getCurrentIndex();
		
		//check if there's a next page
		if(currentIndex < history.getEntries().size()-1) {
			history.go(1);
		}
	});
	
	Button launch = new Button();
	ImageView goImage = new ImageView("/images/gogreen1.png");
	goImage.setFitWidth(19);
	goImage.setFitHeight(19);
	launch.setGraphic(goImage);
	launch.setOnAction(e-> {
		String url = textField.getText();
		if(!url.contains(" ") && (url.startsWith("http://") || url.startsWith("https://") || url.contains("."))) {
			if(!url.startsWith("http://") && !url.startsWith("https://")) {
				url = "http://"+url;
			}
			webEngine.load(url);
		}
		else {
			String googleSearch = "https://www.google.com/search?q=" + url.replace(" ", "+");
			webEngine.load(googleSearch);
		}
	});
		
	//listening to changes in loaded website and updating the address bar with it
	webEngine.locationProperty().addListener((observable, oldValue, newValue)->textField.setText(newValue));
		
	HBox hBox = new HBox();
	hBox.setPadding(new Insets(10, 10, 10, 10));
	hBox.setSpacing(5);
	hBox.setStyle("-fx-background-color: #006442;");
	hBox.getChildren().addAll(homeButton, backButton, forwardButton, textField, launch, refreshButton, settingsButton);

	VBox root = new VBox();
	root.getChildren().addAll(hBox, webView1);
	
	
	return root;
	}
		
	public void loadURL(String url) {
		webEngine.load(url);
	}
	}

		
		
	
	
	
	
	
	

