package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;

public class Favourite {

	private ObservableList<String>faveList;//user is able to see list
	private WebEngine webEngine;
	
	
	public Favourite(WebEngine webEngine) {
		this.webEngine = webEngine;
		this.faveList = FXCollections.observableArrayList();
	}
	
	
	public void addpagetoFavourites() {
		String currentPage = webEngine.getLocation();
		if(!faveList.contains(currentPage)) {
			faveList.add(currentPage);
		}
	}
	
		void showFavourites() {
		ListView<String>listView = new ListView<>(faveList);
		//context menu to be able to delete favourites
		final ContextMenu contextMenu = new ContextMenu();
		MenuItem deleteItem = new MenuItem("Delete");
		contextMenu.getItems().add(deleteItem);
		
		//handle delete item click
		deleteItem.setOnAction(e-> {
			String selectedFavourites = listView.getSelectionModel().getSelectedItem();
			faveList.remove(selectedFavourites);
		});
		
		listView.setContextMenu(contextMenu);//set context menu to the list view
		
		listView.setOnMouseClicked(event-> {
			if(event.getClickCount()==2) { //for double clicking
				String selectedFavourites = listView.getSelectionModel().getSelectedItem();
			webEngine.load(selectedFavourites);
			}
			});
		
		VBox layout = new VBox(listView);
		Stage favouritesWindow = new Stage();
		favouritesWindow.setTitle("Favourites");
		favouritesWindow.setScene(new Scene(layout, 300, 400));
		favouritesWindow.show();
	}
	
}
