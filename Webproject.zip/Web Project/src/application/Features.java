package application;

import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Features {

	private WebEngine webEngine;
	private Stage stage;
	private WebView webView;
	private TabPane tabPane;
	
	public Features(WebEngine webEngine, WebView webView, Stage stage, TabPane tabPane) {
		this.webEngine = webEngine;
		this.webView = webView;
		this.stage = stage;
		this.tabPane = tabPane;
	}

	public void openTab() {
		Tab newTab = new Tab("New Tab");
		newTab.setContent(new Tabs(tabPane));
		newTab.setClosable(true);
		tabPane.getTabs().add(tabPane.getTabs().size()-1, newTab);
		tabPane.getSelectionModel().select(newTab);
	}
	
	public Button buildHomeButton() {
		Button homeButton = new Button();
		ImageView homeImage = new ImageView("/images/homegreen1.png");
		homeImage.setFitWidth(18);
		homeImage.setFitHeight(18);
		homeButton.setGraphic(homeImage);
		homeButton.setOnAction(e->webEngine.load("http://www.google.com"));
		return homeButton;
		}
	
	public MenuManager buildMenuButton() {
	//this contains all items of the menu button
	MenuManager menuDropdowns = new MenuManager(webEngine, webView, stage, tabPane, this);
	return menuDropdowns;
	}
	
	public Settings buildSettingsButton() {
	//this contains all items of the settings button
	Settings settingsDropdowns = new Settings(webView);
	return settingsDropdowns;
	}
	
	public Button buildRefreshButton() {
		Button refreshButton = new Button();
		ImageView refreshImage = new ImageView("/images/refreshgreen2.png");
		refreshImage.setFitWidth(18);
		refreshImage.setFitHeight(18);
		refreshButton.setGraphic(refreshImage);
		refreshButton.setOnAction(e->webEngine.reload());
		return refreshButton;
	}
	
	
	public Button buildBackButton() {
		Button backButton = new Button();
		ImageView backImage = new ImageView("/images/backgreen4.png");
		backImage.setFitWidth(18);
		backImage.setFitHeight(18);
		backButton.setGraphic(backImage);
		backButton.setOnAction(e-> {
		final WebHistory history = webEngine.getHistory();
		int currentIndex = history.getCurrentIndex();

		
		if(currentIndex>0) {//check if there's a previous page
			history.go(-1);
		}
		});
		return backButton;
	}

	public Button buildForwardButton() {
		Button forwardButton = new Button();
		ImageView forwardImage = new ImageView("/images/forwardgreen1.png");
		forwardImage.setFitWidth(18);
		forwardImage.setFitHeight(18);
		forwardButton.setGraphic(forwardImage);
		forwardButton.setOnAction(e-> {
			final WebHistory history = webEngine.getHistory();
			int currentIndex = history.getCurrentIndex();
			
			
			if(currentIndex < history.getEntries().size()-1) {
				history.go(1);
			}
		});
		return forwardButton;
		}
	
	public Button buildLaunchButton(TextField textField) {
		Button launch = new Button();
		ImageView goImage = new ImageView("/images/gogreen2.png");
		goImage.setFitWidth(19);
		goImage.setFitHeight(19);
		launch.setGraphic(goImage);
		launch.setOnAction(e->loadURL(textField));
		return launch;
			}
	
	public TextField buildurlTextField() {
		TextField textField = new TextField();
		textField.setOnAction(e->loadURL(textField));
		return textField;
			}
	
	private void loadURL(TextField textField) {
		String url = textField.getText();
		if(!url.contains(" ") && (url.startsWith("http://") || url.startsWith("https://") || url.contains("."))) {
			if(!url.startsWith("http://") && !url.startsWith("https://")) {
				url = "http://"+url;
			}
			webEngine.load(url);
		}
		else {
			String googleSearch = "https://www.google.com/search?q=" + url.replace(" ", "+");
			webEngine.load(googleSearch);
		}
	 
	}
}





