package application;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebHistory.Entry;
import javafx.stage.Stage;

public class Histories {

	private WebEngine webEngine;
	
	
	public Histories(WebEngine webEngine) {
		this.webEngine = webEngine;
	}
	
	
	public void showHistory() {
		ObservableList<Entry> entry = webEngine.getHistory().getEntries();
		ListView<Entry> seehistoryList = new ListView<>(entry);
		seehistoryList.setOnMouseClicked(event-> {
			if(event.getClickCount()==2) {
				Entry selectedEntry = seehistoryList.getSelectionModel().getSelectedItem();
				webEngine.load(selectedEntry.getUrl());
			}
		});
		VBox layout = new VBox(seehistoryList);
		Stage historyWindow = new Stage();
		historyWindow.setTitle("Browser History");
		historyWindow.setScene(new Scene(layout, 500, 400));
		historyWindow.show();		
	}
	
	public void deleteHistory() {
		ButtonType yes = new ButtonType("What are you hiding?", ButtonBar.ButtonData.OK_DONE);
		ButtonType no = new ButtonType("Don't do it!", ButtonBar.ButtonData.CANCEL_CLOSE);
		
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "", no, yes);
		ImageView alertImage = new ImageView("/images/sademoji.png");
		alertImage.setFitHeight(90);
		alertImage.setFitWidth(150);
		alert.setGraphic(alertImage);
		alert.setTitle("WARNING");
		alert.setHeaderText("Are you sure you want to clear History");
		alert.setContentText("Doing so will delete all your History");
		alert.showAndWait().ifPresent(response-> {
			if(response==yes) {
				WebHistory history = webEngine.getHistory();
				ObservableList<WebHistory.Entry>entry = history.getEntries();
				history.go(0);
				entry.clear();
			}
		});
	}
}







