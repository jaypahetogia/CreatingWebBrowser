package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;



public class Main extends Application {
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		TabPane tabPane = new TabPane();
		
		//setting an image as the background of the tab - (IS NOT SHOWING THOUGH)
		Image backgroundImage = new Image(getClass().getResourceAsStream("/images/technology.jpg"));
		BackgroundSize backgroundSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false);
		BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, backgroundSize);
		tabPane.setBackground(new Background(background));
		
		Tab mainTab = new Tab("Home");
		mainTab.setContent(new Tabs(tabPane));//adds initial tab
		
		
		mainTab.setClosable(true);
		tabPane.getTabs().add(mainTab);
		
		Tab createTab = new Tab("+");
		createTab.setClosable(false);
		tabPane.getTabs().add(createTab);
		
		tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldTab, newTab)-> {
			if(newTab == createTab) {
				Tab goTab = new Tab("New Tab");
				goTab.setContent(new Tabs(tabPane));
				goTab.setClosable(true);
				tabPane.getTabs().add(tabPane.getTabs().size()-1, goTab);
				tabPane.getSelectionModel().select(goTab);
			}
		});
	
	Scene scene = new Scene(tabPane, 800, 600);
	primaryStage.setTitle("Welcome to My Browser");
	primaryStage.setScene(scene);
	primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
