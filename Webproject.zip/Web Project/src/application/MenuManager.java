package application;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class MenuManager {

	private MenuButton menuButton;
	private Favourite favourite;
	private Histories histories;
	private WebEngine webEngine;
	private Save saveit;
	private Print printitbro;
	private TabPane mainTabPane;
	private Features features;
	
	public MenuManager(WebEngine webEngine, WebView webView, Stage stage, TabPane tabPane, Features features) {
		this.mainTabPane = tabPane;
		this.webEngine = webEngine;
		this.features = features;
		
		
		//Creating our menu button with an image
		menuButton = new MenuButton();
		ImageView menuImage = new ImageView("/images/menu2.png");
		menuImage.setFitWidth(18);
		menuImage.setFitHeight(18);
		menuButton.setGraphic(menuImage);
		
//------------------------->>>FAVOURITES ITEM<<<----------------------------		
		favourite = new Favourite(webEngine);
		Menu favouritesItem = new Menu("Favourites");
		
		MenuItem addfavouritesItem = new MenuItem("Add page to your Favourites");
		addfavouritesItem.setOnAction(e->favourite.addpagetoFavourites());
		
		MenuItem viewfavouritesItem = new MenuItem("View Favourites");
		viewfavouritesItem.setOnAction(e->favourite.showFavourites());
		
		favouritesItem.getItems().addAll(addfavouritesItem, viewfavouritesItem);	
		
//----------------------------->>>HISTORY ITEM<<<-------------------------------------		
		histories = new Histories(webEngine);
		Menu historyItem = new Menu("History");
		MenuItem seeHistoryItem = new MenuItem("View History");
        seeHistoryItem.setOnAction(e -> histories.showHistory());
        MenuItem clearHistoryItem = new MenuItem("Clear History");
        clearHistoryItem.setOnAction(e -> histories.deleteHistory());
        historyItem.getItems().addAll(seeHistoryItem, clearHistoryItem);
        
        
        
        MenuItem htmlItem = new MenuItem("HTML");
		htmlItem.setOnAction(e->viewHTML());
		
		MenuItem refreshItem = new MenuItem("Refresh");
		refreshItem.setOnAction(e->webEngine.reload());
		
		saveit = new Save(webEngine);
		MenuItem saveItem = new MenuItem("Save");
		saveItem.setOnAction(e->saveit.savePage());
		
		printitbro = new Print(webView);
		MenuItem printItem = new MenuItem("Print");
		printItem.setOnAction(e->printitbro.printwebPage());

		MenuItem newtabItem = new MenuItem("New Tab");
		newtabItem.setOnAction(e->features.openTab());
		
		
		MenuItem exitItem = new MenuItem("Exit");
		exitItem.setOnAction(e-> {
			Alert exitAlert =  new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit?\nDoing so will close the browser.",
					ButtonType.YES, ButtonType.NO);
			exitAlert.setTitle("Warning");
			exitAlert.setHeaderText("Confirm Exit");
			ButtonType result = exitAlert.showAndWait().orElse(ButtonType.NO);
			if(ButtonType.YES.equals(result))	{
				stage.close();
			}
		
		});
		
		menuButton.getItems().addAll(refreshItem, newtabItem, favouritesItem, historyItem, htmlItem, saveItem, printItem, exitItem);
	}

	private void viewHTML() {
		String htmlWeb = (String)webEngine.executeScript("document.documentElement.outerHTML");
		TextArea textArea = new TextArea(htmlWeb);
		textArea.setWrapText(true);
		VBox layout = new VBox(textArea);
		Stage htmlWindow = new Stage();
		htmlWindow.setTitle("HTML Version");
		htmlWindow.setScene(new Scene(layout, 600, 400));
		htmlWindow.show();
		
	}

	public MenuButton getMenuButton() {
		return menuButton;
		
	}
}
