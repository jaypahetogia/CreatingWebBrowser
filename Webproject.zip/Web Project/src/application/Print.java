package application;

import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.control.Alert;
import javafx.scene.web.WebView;

public class Print {

	private WebView webView;
	
	public Print(WebView webView) {
		this.webView = webView;
	}
	
	public void printwebPage() {
		Printer printer = Printer.getDefaultPrinter();
		PrinterJob job = PrinterJob.createPrinterJob(printer);
		if(job != null) {
			boolean awesome = job.printPage(webView);
			if(awesome) {
				job.endJob();
			}
			else {
				Alert printerAlert = new Alert(Alert.AlertType.ERROR);
				printerAlert.setTitle("Print Job Failed");
				printerAlert.setContentText("Something has gone HORRIBLY wrong. Please check and try again");
			}
		}
	}
	
}
