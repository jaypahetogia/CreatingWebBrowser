package application;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javafx.scene.web.WebEngine;

public class Save {

	private WebEngine webEngine;
	
	
	public Save(WebEngine webEngine) {
		
		this.webEngine = webEngine;
	}
	
	public void savePage() {
		//choose where to save file in html form
		javafx.stage.FileChooser fileChooser = new javafx.stage.FileChooser();
		fileChooser.setTitle("Save web page");
		fileChooser.getExtensionFilters().add(new javafx.stage.FileChooser.ExtensionFilter("HTML Files", "*.html"));
		java.io.File file = fileChooser.showSaveDialog(null);
		
		if(file != null) {
			try {
				//transform the doc into a string of html
				Transformer transformer = TransformerFactory.newInstance().newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty(OutputKeys.METHOD, "xml");
				DOMSource source = new DOMSource(webEngine.getDocument());
				java.io.StringWriter writer = new java.io.StringWriter();
				StreamResult result = new StreamResult(writer);
				transformer.transform(source, result);
				String html = writer.toString();
				
				//write the html to the file
				java.nio.file.Path path = Paths.get(file.toURI());
				Files.write(path,  html.getBytes());
				
			} catch(TransformerException | IOException e) {
				e.printStackTrace();
					
	
}
}
	}
}