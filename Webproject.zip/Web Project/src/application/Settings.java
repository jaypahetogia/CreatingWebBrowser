package application;

import javafx.scene.Scene;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Settings {

	private WebEngine webEngine;
	private MenuButton settingsButton;
	private WebView webView;
	
	public Settings(WebView webView) {
		this.webView = webView;
		this.webEngine = webView.getEngine();
		this.settingsButton = new MenuButton();
		
		ImageView settingsImage = new ImageView("/images/settings.gif");
		settingsImage.setFitWidth(20);
		settingsImage.setFitHeight(20);
		settingsButton.setGraphic(settingsImage);
		settingsButton.getItems().addAll(new MenuItem("Color themes"), new MenuItem("Privacy"), new MenuItem("Properties"), new MenuItem("Advanced"));
		
	MenuItem zoomItem = new MenuItem("Zoom");
	zoomItem.setOnAction(e->showZoomSlider());
	
	
	MenuItem appstoreItem = new MenuItem("App Store");
	appstoreItem.setOnAction(e->webEngine.load("http://www.appstore.com"));
	
	settingsButton.getItems().addAll(zoomItem, appstoreItem);
	
	
	}
	
	public void showZoomSlider() {
		Slider zoomSlider = new Slider(0.5, 3.0, 1.0); 
		zoomSlider.setShowTickLabels(true);
		zoomSlider.setShowTickMarks(true);
		zoomSlider.setMajorTickUnit(0.5);
		zoomSlider.setMinorTickCount(5);
		
		//Bind the webview of zoom to the value of the slider
		webView.zoomProperty().bind(zoomSlider.valueProperty());
		
		VBox layout = new VBox(zoomSlider);
		layout.setBorder(new Border(new BorderStroke(Color.RED, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(3))));
		Image zoomImage = new Image("/images/zoom.png");
		BackgroundSize backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
		BackgroundImage background = new BackgroundImage(zoomImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
		layout.setBackground(new Background(background));
		
		Stage zoomStage = new Stage();
		zoomStage.setTitle("Zoom");
		zoomStage.setScene(new Scene(layout, 300, 50));
		zoomStage.show();
	}
	
	public MenuButton getSettingsButton() {
		return settingsButton;
	}
	
	
	
	
	
}
