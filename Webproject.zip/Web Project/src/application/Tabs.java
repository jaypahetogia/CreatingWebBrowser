package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Tabs extends VBox {
private Stage stage;
private TabPane tabPane;
	
	public Tabs(TabPane tabPane) {
		this.tabPane = tabPane;
		this.setStyle("-fx-background-color: lightblue;");
		
		WebView webView = new WebView();
		WebEngine webEngine = webView.getEngine();
		webEngine.load("http://www.google.com");
		
		Features features = new Features(webEngine, webView, stage, this.tabPane);
		
		Button homeButton = features.buildHomeButton();
		Button backButton = features.buildBackButton();
		Button forwardButton = features.buildForwardButton();
		TextField urltextField = features.buildurlTextField();
		Button goButton = features.buildLaunchButton(urltextField);
		Button refreshButton = features.buildRefreshButton();
		MenuManager menuDropdowns = features.buildMenuButton();
		Settings settingsDropdowns = features.buildSettingsButton();
		
		HBox hBox = new HBox();
		hBox.setPadding(new Insets(25, 10, 25, 10));
		hBox.setSpacing(4);
		hBox.setStyle("-fx-background-image: url('/images/backgroundchip.jpg'); -fx-background-size: cover;");
		hBox.getChildren().addAll(homeButton, backButton, forwardButton, urltextField, goButton, refreshButton, menuDropdowns.getMenuButton(), settingsDropdowns.getSettingsButton());
		
		this.getChildren().addAll(hBox, webView);
		VBox.setVgrow(webView, Priority.ALWAYS);
		HBox.setHgrow(urltextField, Priority.ALWAYS);
	}
}
